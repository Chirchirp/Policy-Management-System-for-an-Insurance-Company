-------------Instruction to Runt the codes:------------------------

The files codes have been saved in the folder name"Policy Management System for an Insurance Company"

Please run the codes that have been saved in four different files using Pycharm or on VS Code.

1. For class creation, separate files have been saved for policyholders, products, and Payments, under the names below.
	i) policyholder_class
	ii) product_class
	iii) payment_class
	iv) main_script

2. Use main_script file to display the 3 policyholders created, showing notification on payments made, products, penalties and reminders

3. The file path to github file is: 