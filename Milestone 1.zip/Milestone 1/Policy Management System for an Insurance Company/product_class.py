# Creating class for products:
class Products:
    def __init__(self, name, price, duration):
        self.name = name # Product name
        self.price = price
        self.duration = duration

    # Creating a new product
    def create_policy_product(self):
        print(f"{self.name} has been created")

    # Updating an Existing Product
    def update_policy_product(self, name, price, duration):
        self.name = name
        self.price = price
        self.duration = duration
        print(f"{self.name} has been updated")

    # Suspending a product
    def suspend_policy_product(self):
        print(f"{self.name} has been suspended")
        print(" ")