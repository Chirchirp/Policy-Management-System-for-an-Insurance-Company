class Policyholder:
    def __init__(self, name, user_id, status):
        self.name = name
        self.user_id = user_id
        self.status = status

    # Registering a new policyholder
    def register(self):
        self.status = "Active"

    # Suspending a policy holder
    def suspend(self):
        self.status = "Suspended"

    # Reactivating a policy holder
    def reactivate(self):
        self.status = "Active"  # Corrected to set the status back to "Active"

    # Displaying results of the Policy holder
    def display(self):
        print(f"Name: {self.name}")
        print(f"User ID: {self.user_id}")
        print(f"Policy holder Status: {self.status}")
        print()