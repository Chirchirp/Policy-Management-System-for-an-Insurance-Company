
# Importing class files that have been saved in diffrent files:

from policyholder_class import Policyholder
from payment_class import Payments
from product_class import Products


# Creating 3 sample policyholders
ph1 = Policyholder("Alice Kemikal", "A12345", "Active")
ph2 = Policyholder("Bob Wine", "B67890", "Suspended")
ph3 = Policyholder("Mike Ross", "C57887", "Active")

# Registering 3 products for the policyholders
p1 = Products("Health Insurance", 1000, 12)
p2 = Products("Car Insurance", 500, 6)
p3 = Products("Travel Insurance", 2000, 12)

# Creating 3 sample payments
pay1 = Payments(ph1, p1, "2024-03-01", 1000, "Pending")
pay2 = Payments(ph2, p2, "2024-02-15", 1500, "Paid")
pay3 = Payments(ph3,p3, "2023-08-22", 2000, "Pending")

# Displaying the policy holders
ph1.display()
ph2.display()
ph3.display()

# Processing some payments
pay1.process_payment()
pay2.process_payment()
pay3.process_payment()

# Sending  reminders
pay1.send_reminder()
pay2.send_reminder()
pay3.send_reminder()

# Applying penalties
pay1.apply_penalty()
pay2.apply_penalty()
pay3.apply_penalty()

